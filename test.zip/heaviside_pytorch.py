import torch
import torch.nn as nn


class heaviside(torch.autograd.Function):

    # 必须是staticmethod
    @staticmethod
    # 第一个是ctx，第二个是input，其他是可选参数。
    # ctx在这里类似self，ctx的属性可以在backward中调用。
    def forward(ctx, input):
        ctx.save_for_backward(input)
        i = input.clone()
        ge = torch.ge(input,0).float()
        output = i + (ge.data - i.data)

        return output


    @staticmethod
    def backward(ctx, grad_output): 
        input, = ctx.saved_tensors
        input_grad = grad_output.clone()
        
        ones = torch.ones_like(input)
        zeros = torch.zeros_like(input)
        output_grad = torch.maximum(zeros, torch.abs(ones - input) ) * input_grad

        return output_grad