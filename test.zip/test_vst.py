from vst import *
from add_noise import *
import cv2

bl = 1.0/16.0
iso = 6400

K,B,a,b = noise_model(iso)
print("noise model : ",K,B,a,b)

for luma in range (0,20,1):
    I = np.zeros((256,256))
    I = I + luma/255.0 + bl
    I_noise = add_poisson_gauss_noise(I, bl,a,b)
    
    I_noise_old = addNoise(I,bl,K,B)
    
    tmp = np.clip(I*255,0,255)
    out_file_pth = "./tmp/I_%d.bmp"%(luma)
    cv2.imwrite(out_file_pth, tmp)
    
    tmp = np.clip(I_noise*255,0,255)
    out_file_pth = "./tmp/I_%d_noise.bmp"%(luma)
    cv2.imwrite(out_file_pth, tmp)
    
    
    I_noise_vst = vst(I_noise, bl,a,b)
    I_noise_vst_old = vst(I_noise_old, bl,a,b)
    
    noise_var = np.var(I_noise_vst)
    noise_var_old = np.var(I_noise_vst_old)
    
    print("luma,noise_var = ",luma,noise_var,noise_var_old,noise_var/noise_var_old)

    
    
    