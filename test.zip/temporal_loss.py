import torch
import torch.nn as nn
import numpy as np
import torch.nn.functional as F

class temporal_consistency_loss(nn.Module):
    def __init__(self):
        super(temporal_consistency_loss, self).__init__()
        self.k_sizes = [1, 3, 5, 7]


    def forward(self, label,label_ref, out_img,out_img_ref):
        k_sizes = self.k_sizes
        gt_errors = []
        out_errors = []

        for i in range(len(k_sizes)):
            k_size = k_sizes[i]
            avg_blur = nn.AvgPool2d(k_size, stride=1, padding=int((k_size - 1) / 2))
            gt_error = avg_blur(label) - avg_blur(label_ref)
            out_error = avg_blur(out_img) - avg_blur(out_img_ref)
            gt_errors.append(gt_error)
            out_errors.append(out_error)

        gt_error_rgb_pixel_min = gt_errors[0]
        out_error_rgb_pixel_min = out_errors[0]

        for j in range(1, len(k_sizes)):
            gt_error_rgb_pixel_min = torch.where(torch.abs(out_error_rgb_pixel_min) < torch.abs(out_errors[j]),
                    gt_error_rgb_pixel_min, gt_errors[j])
            out_error_rgb_pixel_min = torch.where(torch.abs(out_error_rgb_pixel_min) < torch.abs(out_errors[j]),
                    out_error_rgb_pixel_min, out_errors[j])

        loss_temporal = F.l1_loss(gt_error_rgb_pixel_min, out_error_rgb_pixel_min)
        return loss_temporal