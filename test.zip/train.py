import os
import argparse
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torchvision.utils as utils
from torch.autograd import Variable
from torch.utils.data import DataLoader
from tensorboardX import SummaryWriter
from models import BPN_NET_80G
from dataset import prepare_data, Dataset
from utils import *
import cv2

os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

parser = argparse.ArgumentParser(description="DnCNN")
parser.add_argument("--preprocess", type=bool, default=False, help='run prepare_data or not')
parser.add_argument("--batchSize", type=int, default=64, help="Training batch size")
parser.add_argument("--num_of_layers", type=int, default=17, help="Number of total layers")
parser.add_argument("--epochs", type=int, default=50, help="Number of training epochs")
parser.add_argument("--milestone", type=int, default=30, help="When to decay learning rate; should be less than epochs")
parser.add_argument("--lr", type=float, default=1e-3, help="Initial learning rate")
parser.add_argument("--outf", type=str, default="logs", help='path of log files')
parser.add_argument("--mode", type=str, default="S", help='with known noise level (S) or blind training (B)')
parser.add_argument("--noiseL", type=float, default=25, help='noise level; ignored when mode=B')
parser.add_argument("--val_noiseL", type=float, default=25, help='noise level used on validation set')
opt = parser.parse_args()


"""
class BPN(nn.Module):
    def __init__(self, B = 8,K=7):
        super(BPN, self).__init__()
        self.B = B
        self.K = K
        padding = 1
        features = 64
        self.conv = nn.Conv2d
        
    def forward(self, kernel, coeff, image):
        k = self.K
        chn,c,w,h = image.size()
        kernel = 2/(1+torch.exp(-kernel)) - 1.0  
        kernel_r = kernel[:,:self.B,:,:].reshape(chn*B,1,k,k)
        kernel_g = kernel[:,self.B:2*self.B,:,:].reshape(chn*B,1,k,k)
        kernel_b = kernel[:,2*self.B:,:,:].reshape(chn*B,1,k,k)
        
        r = image[:,0:1,:,:].reshape(1,chn,w,h)
        g = image[:,1:2,:,:].reshape(1,chn,w,h)
        b = image[:,2:3,:,:].reshape(1,chn,w,h)
        
        r = F.pad(r,(k//2,k//2,k//2,k//2),mode='reflect')
        g = F.pad(g,(k//2,k//2,k//2,k//2),mode='reflect')
        b = F.pad(b,(k//2,k//2,k//2,k//2),mode='reflect')
        
        r_f = self.conv(r,kernel_r, group=chn)
        g_f = self.conv(g,kernel_g, group=chn)
        b_f = self.conv(b,kernel_b, group=chn)
        
        coeff_r = coeff[:,:self.B,:,:]
        coeff_g = coeff[:,self.B:2*self.B,:,:]
        coeff_b = coeff[:,2*self.B:,:,:]
        
        coeff_r = torch.softmax(coeff_r,dim=1)
        coeff_g = torch.softmax(coeff_g,dim=1)
        coeff_b = torch.softmax(coeff_b,dim=1)
        
        r_f = r_f.view(chn,-1,w,h)
        g_f = g_f.view(chn,-1,w,h)
        b_f = b_f.view(chn,-1,w,h)
        
        r_f = r_f*coeff_r
        g_f = r_f*coeff_g
        b_f = r_f*coeff_b
        
        
        r_f = torch.sum(r_f,dim=1, keepdim=True)
        g_f = torch.sum(g_f,dim=1, keepdim=True)
        b_f = torch.sum(b_f,dim=1, keepdim=True)
        
        out = torch.cat([r_f,g_f,b_f],dim=1)
        
        return out
"""

class BPN_rec(nn.Module):
    def __init__(self, B = 8,K=7):
        super(BPN_rec, self).__init__()
        self.B = B
        self.K = K
        
    def forward(self, coeff, kernel, image):
        k = self.K
        chn,c,w,h = image.size()
        kernel = 2/(1+torch.exp(-kernel)) - 1.0  
        
        out = torch.zeros_like(image).cuda()
        for idx in range (c) : 
        
            kernel_cur = kernel[:,idx*self.B:(idx+1)*self.B,:,:].reshape(chn*self.B,1,k,k)

            I = image[:,idx:idx+1,:,:].reshape(1,chn,w,h)
            I = F.pad(I,(k//2,k//2,k//2,k//2),mode='reflect')
            
            I_f = F.conv2d(I,kernel_cur, groups=chn)
            
            coeff_cur = coeff[:,idx*self.B:(idx+1)*self.B,:,:]
            
            coeff_cur = torch.softmax(coeff_cur,dim=1)
            
            I_f = I_f.view(chn,-1,w,h)
            
            I_f = I_f*coeff_cur
            
            I_f = torch.sum(I_f,dim=1, keepdim=True)
            
            out[:,idx:idx+1,:,:] = I_f
        #print("====out:",out.size())        
        return out

def main():
    # Load dataset
    print('Loading dataset ...\n')
    dataset_train = Dataset(train=True)
    dataset_val = Dataset(train=False)
    loader_train = DataLoader(dataset=dataset_train, num_workers=4, batch_size=opt.batchSize, shuffle=True)
    print("# of training samples: %d\n" % int(len(dataset_train)))
    # Build model
    net = BPN_NET_80G(4, 1, 0, kernel_size=7, basis_size=8)
    
    run_BPN_rec = BPN_rec(B = 8,K=7).cuda()
    #net.apply(weights_init_kaiming)
    criterion = nn.MSELoss(size_average=False)
    # Move to GPU
    device_ids = [0]
    model = nn.DataParallel(net, device_ids=device_ids).cuda()
    criterion.cuda()
    # Optimizer
    optimizer = optim.Adam(model.parameters(), lr=opt.lr)
    # training
    writer = SummaryWriter(opt.outf)
    step = 0
    noiseL_B=[0,55] # ingnored when opt.mode=='S'
    for epoch in range(opt.epochs):
        if epoch < opt.milestone:
            current_lr = opt.lr
        else:
            current_lr = opt.lr / 10.
        # set learning rate
        for param_group in optimizer.param_groups:
            param_group["lr"] = current_lr
        #print('learning rate %f' % current_lr)
        # train
        for i, data in enumerate(loader_train, 0):
            # training step
            model.train()
            model.zero_grad()
            optimizer.zero_grad()
            img_train = data
            if opt.mode == 'S':
                noise = torch.FloatTensor(img_train.size()).normal_(mean=0, std=opt.noiseL/255.)
            if opt.mode == 'B':
                noise = torch.zeros(img_train.size())
                stdN = np.random.uniform(noiseL_B[0], noiseL_B[1], size=noise.size()[0])
                for n in range(noise.size()[0]):
                    sizeN = noise[0,:,:,:].size()
                    noise[n,:,:,:] = torch.FloatTensor(sizeN).normal_(mean=0, std=stdN[n]/255.)
            imgn_train = img_train + noise
            img_train, imgn_train = Variable(img_train.cuda()), Variable(imgn_train.cuda())
            noise = Variable(noise.cuda())
            
            #print("===========imgn_train:",imgn_train.size())
            
            net_in = space_to_depth(imgn_train,2)
            #print("===========net_in:",net_in.size())
            coeff,basis = model(net_in)
            
            out_train = run_BPN_rec(coeff,basis,imgn_train)
            
            
            loss = torch.mean(torch.abs(out_train - img_train))
            loss.backward()
            optimizer.step()
            
            
            if step == 0:
                loss_total_avg = 0
            loss_total_avg += loss.item()
            
            if step % 200 == 0:
                loss_total_avg = loss_total_avg/200
                print("[epoch %d][%d/%d] loss: %.5f , %.6f" %(epoch+1, i+1, len(loader_train), loss_total_avg,current_lr))
                loss_total_avg = 0
                
            if step % 1000 == 0:
                out_np = img_train.cpu().detach().numpy()
                tmp = out_np[0].transpose((1, 2, 0))
                tmp = np.clip(tmp*255,0,255)
                out_file_pth = "./train_output/%d_label.bmp"%(step)
                cv2.imwrite(out_file_pth, tmp)
                
                out_np = imgn_train.cpu().detach().numpy()
                tmp = out_np[0].transpose((1, 2, 0))
                tmp = np.clip(tmp*255,0,255)
                out_file_pth = "./train_output/%d_noisy.bmp"%(step)
                cv2.imwrite(out_file_pth, tmp)
                
                out_np = out_train.cpu().detach().numpy()
                tmp = out_np[0].transpose((1, 2, 0))
                tmp = np.clip(tmp*255,0,255)
                out_file_pth = "./train_output/%d_netout.bmp"%(step)
                cv2.imwrite(out_file_pth, tmp)
                
            step += 1
        
        torch.save(model.state_dict(), os.path.join(opt.outf, 'net_%d.pth'%(epoch)))

if __name__ == "__main__":
    print("--------------opt.preprocess:",opt.preprocess)
    if 0:#opt.preprocess:
        if opt.mode == 'S':
            prepare_data(data_path='data', patch_size=128, stride_in=0, aug_times=1)
        if opt.mode == 'B':
            prepare_data(data_path='data', patch_size=128, stride_in=0, aug_times=2)
    else:
        main()
