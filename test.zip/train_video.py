import os
import argparse
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torchvision.utils as utils
from torch.autograd import Variable
from torch.utils.data import DataLoader
from tensorboardX import SummaryWriter
from models import CNN_NET_80G
from dataset_video import prepare_data, Dataset
from utils import *
import cv2
from contextual_loss import ContextualLoss
import heaviside_pytorch
import HEM_pytorch
from torch.cuda.amp import autocast, GradScaler

use_ctx = 1
use_asymloss = 0
use_hem = 1
train_data_split_num = 2

finetune_final_result = 0

os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

parser = argparse.ArgumentParser(description="DnCNN")
parser.add_argument("--preprocess", type=bool, default=False, help='run prepare_data or not')
parser.add_argument("--batchSize", type=int, default=16, help="Training batch size")
parser.add_argument("--num_of_layers", type=int, default=17, help="Number of total layers")
parser.add_argument("--epochs", type=int, default=50, help="Number of training epochs")
parser.add_argument("--milestone", type=int, default=30, help="When to decay learning rate; should be less than epochs")
parser.add_argument("--lr", type=float, default=1e-3, help="Initial learning rate")
parser.add_argument("--outf", type=str, default="logs", help='path of log files')
parser.add_argument("--mode", type=str, default="S", help='with known noise level (S) or blind training (B)')
parser.add_argument("--noiseL", type=float, default=25, help='noise level; ignored when mode=B')
parser.add_argument("--val_noiseL", type=float, default=25, help='noise level used on validation set')
opt = parser.parse_args()


"""
class BPN(nn.Module):
    def __init__(self, B = 8,K=7):
        super(BPN, self).__init__()
        self.B = B
        self.K = K
        padding = 1
        features = 64
        self.conv = nn.Conv2d
        
    def forward(self, kernel, coeff, image):
        k = self.K
        chn,c,w,h = image.size()
        kernel = 2/(1+torch.exp(-kernel)) - 1.0  
        kernel_r = kernel[:,:self.B,:,:].reshape(chn*B,1,k,k)
        kernel_g = kernel[:,self.B:2*self.B,:,:].reshape(chn*B,1,k,k)
        kernel_b = kernel[:,2*self.B:,:,:].reshape(chn*B,1,k,k)
        
        r = image[:,0:1,:,:].reshape(1,chn,w,h)
        g = image[:,1:2,:,:].reshape(1,chn,w,h)
        b = image[:,2:3,:,:].reshape(1,chn,w,h)
        
        r = F.pad(r,(k//2,k//2,k//2,k//2),mode='reflect')
        g = F.pad(g,(k//2,k//2,k//2,k//2),mode='reflect')
        b = F.pad(b,(k//2,k//2,k//2,k//2),mode='reflect')
        
        r_f = self.conv(r,kernel_r, group=chn)
        g_f = self.conv(g,kernel_g, group=chn)
        b_f = self.conv(b,kernel_b, group=chn)
        
        coeff_r = coeff[:,:self.B,:,:]
        coeff_g = coeff[:,self.B:2*self.B,:,:]
        coeff_b = coeff[:,2*self.B:,:,:]
        
        coeff_r = torch.softmax(coeff_r,dim=1)
        coeff_g = torch.softmax(coeff_g,dim=1)
        coeff_b = torch.softmax(coeff_b,dim=1)
        
        r_f = r_f.view(chn,-1,w,h)
        g_f = g_f.view(chn,-1,w,h)
        b_f = b_f.view(chn,-1,w,h)
        
        r_f = r_f*coeff_r
        g_f = r_f*coeff_g
        b_f = r_f*coeff_b
        
        
        r_f = torch.sum(r_f,dim=1, keepdim=True)
        g_f = torch.sum(g_f,dim=1, keepdim=True)
        b_f = torch.sum(b_f,dim=1, keepdim=True)
        
        out = torch.cat([r_f,g_f,b_f],dim=1)
        
        return out
"""

class BPN_rec(nn.Module):
    def __init__(self, B = 8,K=7):
        super(BPN_rec, self).__init__()
        self.B = B
        self.K = K
        
    def forward(self, coeff, kernel, image):
        k = self.K
        chn,c,w,h = image.size()
        kernel = 2/(1+torch.exp(-kernel)) - 1.0  
        
        out = torch.zeros_like(image).cuda()
        for idx in range (c) : 
        
            kernel_cur = kernel[:,idx*self.B:(idx+1)*self.B,:,:].reshape(chn*self.B,1,k,k)

            I = image[:,idx:idx+1,:,:].reshape(1,chn,w,h)
            I = F.pad(I,(k//2,k//2,k//2,k//2),mode='reflect')
            
            I_f = F.conv2d(I,kernel_cur, groups=chn)
            
            coeff_cur = coeff[:,idx*self.B:(idx+1)*self.B,:,:]
            
            coeff_cur = torch.softmax(coeff_cur,dim=1)
            
            I_f = I_f.view(chn,-1,w,h)
            
            I_f = I_f*coeff_cur
            
            I_f = torch.sum(I_f,dim=1, keepdim=True)
            
            out[:,idx:idx+1,:,:] = I_f
        #print("====out:",out.size())        
        return out

#torch
def warp_torch(x,xymap,w,h):
    
    vgrid_x = 2.0 * xymap[:, 0,:, :] / max(w - 1, 1) - 1.0
    vgrid_y = 2.0 * xymap[:, 1,:, :] / max(h - 1, 1) - 1.0
    vgrid_scaled = torch.stack((vgrid_x, vgrid_y), dim=3)
    output = F.grid_sample(x, vgrid_scaled, mode='nearest', padding_mode='reflection')
         
    return  output   

def main(pretrained_ckpt):
    # Load dataset
    print('Loading dataset ...\n')
    dataset_train = Dataset(train=True)
    
    batch_size_split = opt.batchSize//train_data_split_num

    loader_train = DataLoader(dataset=dataset_train, num_workers=1, batch_size=opt.batchSize, shuffle=True)
    print("# of training samples: %d\n" % int(len(dataset_train)))
    # Build model
    
    #in : 3x4RGB + pre 3*4 = 24
    net = CNN_NET_80G(in_dims = 24, out_chn = 3)
    
    
    scaler = GradScaler()
    
    warm_up_step = 1000
    if pretrained_ckpt > 0:
        warm_up_step = 0
        checkpoint_PATH = os.path.join(opt.outf, 'net_epoch%d.pth'%(pretrained_ckpt))
        model_CKPT = torch.load(checkpoint_PATH)    # 加载模型参数
        
        model_CKPT_new = {k.replace('module.',''):v for k,v in model_CKPT.items()}
        
        net.load_state_dict(model_CKPT_new)  
    
    
    #################load a pre trained DM net for raw
    """
    net_dm = DM_NET(in_dims = 24, out_chn = 3)

    checkpoint_PATH = os.path.join(opt.outf, 'net_epoch%d.pth'%(pretrained_ckpt_dm))
    model_CKPT = torch.load(checkpoint_PATH)    # 加载模型参数
    
    model_CKPT_new = {k.replace('module.',''):v for k,v in model_CKPT.items()}
    
    net_dm.load_state_dict(model_CKPT_new)  
    model_dm = nn.DataParallel(net_dm, device_ids=device_ids).cuda()    
    """    
    #net.apply(weights_init_kaiming)

    
    ctx_loss_func = ContextualLoss()
    hem_loss_func = HEM_pytorch.HEM()
    
    #heaviside_run = heaviside_pytorch.heaviside.apply()
    asym_w = 1 #asym_w = 1 :  not use asymloss
    if use_asymloss :
        asym_w = 3

    hem_w = 3
    use_noisy_label = 1 #label add noise to label, Increase the naturalness of network results  while preserve more details
    
    # Move to GPU
    device_ids = [0]
    model = nn.DataParallel(net, device_ids=device_ids).cuda()
    
    
    # Optimizer
    optimizer = optim.Adam(model.parameters(), lr=opt.lr)
    # training
    writer = SummaryWriter(opt.outf)
    step = 0
    noiseL_B=[0,55] # ingnored when opt.mode=='S'
    for epoch in range(pretrained_ckpt+1,opt.epochs):
        if step < 100000:
            current_lr = opt.lr
        elif step < 200000:
            current_lr = opt.lr / 3.
        elif step < 300000:
            current_lr = opt.lr / 2.
        else:
            current_lr = opt.lr / 2.
        # set learning rate
        for param_group in optimizer.param_groups:
            param_group["lr"] = current_lr
        #print('learning rate %f' % current_lr)
        # train
        for i, [data,data_xymap] in enumerate(loader_train, 0):
            # training step
            #torch.cuda.empty_cache()
            
            model.train()
            model.zero_grad()
            optimizer.zero_grad()
            
            #print ("===================data:",data.size())
            #print ("===================data_xymap:",data_xymap.size())
            target = data.permute(0,1,4,2,3)
            
            #print ("===================target:",target.size())
            if opt.mode == 'S':
                noise = torch.FloatTensor(target.size()).normal_(mean=0, std=opt.noiseL/255.)
            if opt.mode == 'B':
                noise = torch.zeros(target.size())
                stdN = np.random.uniform(noiseL_B[0], noiseL_B[1], size=noise.size()[0])
                for n in range(noise.size()[0]):
                    sizeN = noise[0,:,:,:].size()
                    noise[n,:,:,:] = torch.FloatTensor(sizeN).normal_(mean=0, std=stdN[n]/255.)
            net_noisey_in = target + noise
            target, net_noisey_in = Variable(target), Variable(net_noisey_in)
            #noise = Variable(noise.cuda())
            #data_xymap = data_xymap.cuda()
            
            #with autocast():
            loss = 0
            for frm_idx in range (15):
                net_noisey_in_cur = net_noisey_in[:,frm_idx,:,:,:].cuda()
                target_cur = target[:,frm_idx,:,:,:].cuda()
                xymap_cur = data_xymap[:,frm_idx,:,:,:].cuda()
                #print("===========net_noisey_in:",net_noisey_in.size())
                
                zeros_map = torch.zeros_like(net_noisey_in_cur).cuda()
                if frm_idx == 0:
                    pre_warp = zeros_map
                
                cur_in = space_to_depth(net_noisey_in_cur,2)
                pre_in = space_to_depth(pre_warp,2)
                
                net_in = torch.cat([cur_in,pre_in],1)
                
                
                #
                out_train = model(net_in)
                
                
                ###########################
                if use_noisy_label:
                    """
                    if use_bayer_in:
                        noisy_img = model_dm(cur_in)
                    else:
                        noisy_img = net_noisey_in_cur
                    """
                    noisy_img = net_noisey_in_cur
                    alpha = 0.02 #can calc depand on luma and detail strength
                    label = target_cur * (1.0 - alpha) + noisy_img * alpha
                else:
                    label = target_cur       
                ###########################
                    
                
                #=============================================================
                #L1 & asymloss
                h_sensor = (label - target_cur) * (target_cur - out_train)
                h = heaviside_pytorch.heaviside.apply(h_sensor)
                l1_loss = torch.mean(torch.abs(out_train - label) * (1 + (asym_w-1) * h))
                #smape loss
                #l1_loss = torch.mean(torch.abs(out_train - target_cur) * (1 + (asym_w-1) * h)/(target_cur + torch.abs(out_train) + 1e-3))
                loss += l1_loss
                
                #============================================================
                #HEM
                if use_hem:
                    hem_loss = hem_loss_func(label,out_train,asym_w)
                    hem_loss_o = hem_w*hem_loss
                    loss += hem_loss_o
                
                if use_ctx == 1:
                    #out_train_3chn = torch.cat([out_train,out_train,out_train],dim=1)
                    #target_3chn = torch.cat([target,target,target],dim=1)
                    ctx_loss = ctx_loss_func(out_train, label)
                    
                    ctx_loss_o = ctx_loss * 0.1
                    loss +=  ctx_loss_o
                
                if step < warm_up_step:
                    pre_warp = warp_torch(target_cur,xymap_cur,128,128)
                else:
                    pre_warp = warp_torch(out_train,xymap_cur,128,128)
                    
                if step % 1000 == 0 and (frm_idx == 12):
                    out_np = label[0,:,:,:].cpu().detach().numpy()
                    tmp = out_np.transpose((1, 2, 0))
                    tmp = np.clip(tmp*255,0,255)
                    out_file_pth = "./train_output/%d_label_%d.bmp"%(step,frm_idx)
                    cv2.imwrite(out_file_pth, tmp)
                    
                    out_np = net_noisey_in_cur[0,:,:,:].cpu().detach().numpy()
                    tmp = out_np.transpose((1, 2, 0))
                    tmp = np.clip(tmp*255,0,255)
                    out_file_pth = "./train_output/%d_noisy_%d.bmp"%(step,frm_idx)
                    cv2.imwrite(out_file_pth, tmp)
                    
                    #out_np = pre_warp[0,:,:,:].cpu().detach().numpy()
                    #tmp = out_np.transpose((1, 2, 0))
                    #tmp = np.clip(tmp*255,0,255)
                    #out_file_pth = "./train_output/%d_netout_warp_%d.bmp"%(step,frm_idx)
                    #cv2.imwrite(out_file_pth, tmp)
                    
                    out_np = out_train.cpu().detach().numpy()
                    tmp = out_np[0].transpose((1, 2, 0))
                    tmp = np.clip(tmp*255,0,255)
                    out_file_pth = "./train_output/%d_netout_%d.bmp"%(step,frm_idx)
                    cv2.imwrite(out_file_pth, tmp)
                    
                    out_np = out_train_cur.cpu().detach().numpy()
                    tmp = out_np[0].transpose((1, 2, 0))
                    tmp = np.clip(tmp*255,0,255)
                    out_file_pth = "./train_output/%d_netout_cur_%d.bmp"%(step,frm_idx)
                    cv2.imwrite(out_file_pth, tmp)
                    
                    out_np = out_train_pre.cpu().detach().numpy()
                    tmp = out_np[0].transpose((1, 2, 0))
                    tmp = np.clip(tmp*255,0,255)
                    out_file_pth = "./train_output/%d_netout_pre_%d.bmp"%(step,frm_idx)
                    cv2.imwrite(out_file_pth, tmp)
                    
                    out_np = weight.cpu().detach().numpy()
                    tmp = out_np[0].transpose((1, 2, 0))
                    tmp = np.clip(tmp*255,0,255)
                    out_file_pth = "./train_output/%d_weight_%d.bmp"%(step,frm_idx)
                    cv2.imwrite(out_file_pth, tmp.astype(np.uint8))
                    
            #scaler.scale(loss).backward()
            #scaler.step(optimizer)
            #scaler.update()
            loss.backward()
            optimizer.step()
            
            
            if step == 0:
                loss_total_avg = 0
                l1_total_avg = 0
                ctx_total_avg = 0
                hem_avg = 0
            loss_total_avg += loss.item()
            l1_total_avg += l1_loss.item()
            if use_ctx == 1:
                ctx_total_avg += ctx_loss_o.item()
            if use_hem:
                hem_avg += hem_loss_o.item()
            
            if step % 200 == 0:
                loss_total_avg = loss_total_avg/200
                l1_total_avg = l1_total_avg/200
                ctx_total_avg = ctx_total_avg/200
                hem_avg = hem_avg/200
                print("[epoch %d][%d] loss: total = %.5f , l1 = %.5f, ctx = %.5f , hem = %.5f , lr = %.6f" %(epoch, step, loss_total_avg,l1_total_avg,ctx_total_avg,hem_avg,current_lr))
                loss_total_avg = 0
                l1_total_avg = 0
                ctx_total_avg = 0
                hem_avg = 0
                
            #if step % 1000 == 0:
            #    torch.save(model.state_dict(), os.path.join(opt.outf, 'net_step%d.pth'%(step)))
                
            step += 1
        
        ckpt_out_filepath = os.path.join(opt.outf, 'net_epoch%d.pth'%(epoch))
        print("save ckpt :",ckpt_out_filepath)
        torch.save(model.state_dict(), ckpt_out_filepath)

if __name__ == "__main__":
    #prepare_data(data_path='data', patch_size=128, stride_in=0, aug_times=2)
    pretrained_ckpt = 2
    main(pretrained_ckpt)
