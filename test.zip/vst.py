import torch
import torch.nn as nn
import numpy as np



def vst(I, bl,a,b):
    g = bl
    z_a = (I-g)/a
    z_b = max(b,0.0)/(a**2)
    I_vst = 2*np.sqrt(np.maximum((I-g)/a+3.0/8.0+z_b,0))
    
    
    return I_vst
    
    
    
    