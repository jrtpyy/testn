
import torch
import torch.nn as nn
from torch.autograd import Variable
import torch.nn.functional as F

class TVLoss(nn.Module):
    def __init__(self,TVLoss_weight=1):
        super(TVLoss,self).__init__()
        self.TVLoss_weight = TVLoss_weight

    def forward(self,x):
        batch_size = x.size()[0]
        h_x = x.size()[2]
        w_x = x.size()[3]

        h_tv = x[:,:,1:,:]-x[:,:,:h_x-1,:]
        w_tv = x[:,:,:,1:]-x[:,:,:,:w_x-1]
        h_tv = F.pad(h_tv,pad = (0,0,0,1),mode='constant',value = 0)
        w_tv = F.pad(w_tv,pad = (0,1,0,0),mode='constant',value = 0)
        
        out = torch.stack((h_tv,w_tv),dim = -1)
        return out

