import torch
import torch.nn as nn
import torch.nn.functional as F

class DnCNN(nn.Module):
    def __init__(self, channels, num_of_layers=17):
        super(DnCNN, self).__init__()
        kernel_size = 3
        padding = 1
        features = 64
        layers = []
        layers.append(nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding, bias=False))
        layers.append(nn.ReLU(inplace=True))
        for _ in range(num_of_layers-2):
            layers.append(nn.Conv2d(in_channels=features, out_channels=features, kernel_size=kernel_size, padding=padding, bias=False))
            layers.append(nn.BatchNorm2d(features))
            layers.append(nn.ReLU(inplace=True))
        layers.append(nn.Conv2d(in_channels=features, out_channels=channels, kernel_size=kernel_size, padding=padding, bias=False))
        self.dncnn = nn.Sequential(*layers)
    def forward(self, x):
        out = self.dncnn(x)
        return out



# basic block: SingleConv
class SingleConv(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(SingleConv, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels=in_ch, out_channels=out_ch, kernel_size=3,
                      stride=1, padding=1),
            nn.ReLU()
        )

    def forward(self, data):
        output = self.conv(data)
        return output

# basic block: SingleConv
class SingleConv_res(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(SingleConv_res, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels=in_ch, out_channels=out_ch, kernel_size=3,
                      stride=1, padding=1),
            nn.ReLU()
        )

    def forward(self, data):
        tmp0 = self.conv(data)
        output = tmp0 + data
        return output

class SingleConv_res2(nn.Module):
    def __init__(self, in_ch, mid_chn, out_ch):
        super(SingleConv_res2, self).__init__()
        self.conv0 = nn.Sequential(
            nn.Conv2d(in_channels=in_ch, out_channels=mid_chn, kernel_size=3,
                      stride=1, padding=1),
            nn.ReLU()
        )
        
        self.conv1 = nn.Conv2d(in_channels=mid_chn, out_channels=out_ch, kernel_size=3,stride=1, padding=1)

        self.act = nn.ReLU()
        
    def forward(self, data):
        tmp0 = self.conv0(data)
        tmp1 = self.conv1(tmp0)
        
        output = self.act(tmp1 + data)
        return output
        
# basic block: SingleConv
class SingleConv_res_depthwise(nn.Module):
    def __init__(self, in_ch):
        super(SingleConv_res_depthwise, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels=in_ch, out_channels=in_ch, kernel_size=3,stride=1, padding=1,groups = in_ch),
            nn.ReLU()
        )

    def forward(self, data):
        tmp0 = self.conv(data)
        output = tmp0 + data
        return output

        
class Conv_resBlocks3(nn.Module):
    def __init__(self, in_ch,mid_ch, out_ch):
        super(Conv_resBlocks3, self).__init__()
        self.conv0 = nn.Sequential(nn.Conv2d(in_channels=in_ch, out_channels=mid_ch, kernel_size=3,stride=1, padding=1),nn.ReLU())
        self.conv1 = nn.Sequential(nn.Conv2d(in_channels=mid_ch, out_channels=mid_ch, kernel_size=3,stride=1, padding=1),nn.ReLU())
        self.conv2 = nn.Conv2d(in_channels=mid_ch, out_channels=out_ch, kernel_size=3,stride=1, padding=1)
        self.skip = nn.Conv2d(in_channels=in_ch, out_channels=out_ch, kernel_size=1)
        self.act = nn.ReLU()

    def forward(self, data):
        tmp0 = self.conv0(data)
        tmp1 = self.conv1(tmp0)
        tmp2 = self.conv2(tmp1)
        
        tmp3 = self.skip(data)
        output = self.act(tmp2 + tmp3)
        return output


class Conv_resBlocks2(nn.Module):
    def __init__(self, in_ch,mid_ch, out_ch):
        super(Conv_resBlocks2, self).__init__()
        self.conv0 = nn.Sequential(nn.Conv2d(in_channels=in_ch, out_channels=mid_ch, kernel_size=3,stride=1, padding=1),nn.ReLU())
        self.conv1 = nn.Conv2d(in_channels=mid_ch, out_channels=out_ch, kernel_size=3,stride=1, padding=1)
        self.skip = nn.Conv2d(in_channels=in_ch, out_channels=out_ch, kernel_size=1)
        self.act = nn.ReLU()

    def forward(self, data):
        tmp0 = self.conv0(data)
        tmp1 = self.conv1(tmp0)
        
        tmp2 = self.skip(data)
        output = self.act(tmp1 + tmp2)
        return output

        
# basic block: DownBlock
class DownBlock(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(DownBlock, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels=in_ch, out_channels=out_ch, kernel_size=3,stride=2, padding=1), #
            nn.ReLU()
        )

    def forward(self, data):
        output = self.conv(data)
        return output


# basic block: UpBlock
class UpBlock(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(UpBlock, self).__init__()
        self.conv = nn.Sequential(
            nn.ConvTranspose2d(in_ch, out_ch, kernel_size=2, stride=2),
            nn.ReLU()
        )

    def forward(self, data):
        output = self.conv(data)
        return output

# basic block: UpBlock
class UpBlock_basis(nn.Module):
    def __init__(self, in_ch0,in_ch1, out_ch ):
        super(UpBlock_basis, self).__init__()
        self.conv0 = nn.Sequential(
            nn.Conv2d(in_channels=in_ch0, out_channels=out_ch, kernel_size=3,
                      stride=1, padding=1),
            nn.ReLU()
            )
        self.conv1 = nn.Sequential(
            nn.Conv2d(in_channels=in_ch0, out_channels=out_ch, kernel_size=3,
                      stride=1, padding=1),
            nn.ReLU()
            )
            
        self.conv2 = nn.Sequential(
            nn.Conv2d(in_channels=in_ch1, out_channels=out_ch, kernel_size=1,
                      stride=1, padding=0),
            nn.ReLU()
            )

    def forward(self, data_in0, data_in1):
        tmp0 = F.interpolate(data_in0, scale_factor=2, mode='bilinear')
        tmp0 = self.conv0(tmp0)
        
        tmp1 = torch.mean(data_in1, axis=[2,3], keepdims=True) # 1x1
        tmp1 = self.conv2(tmp1)
        
        output = self.conv1(tmp0+tmp1)
        return output


# BPN basic block: CutEdgeConv
# Used to cut the redundant edge of a tensor after 2*2 Conv2d with valid padding
class CutEdgeConv(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(CutEdgeConv, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels=in_ch, out_channels=out_ch, kernel_size=2,
                      stride=1, padding=0),
            nn.ReLU()
        )

    def forward(self, data):
        output = self.conv(data)
        return output





class BPN_NET_80G(nn.Module):
    def __init__(self,in_dims, out_chn, add_chn, kernel_size=7, basis_size=8):
        super(BPN_NET_80G, self).__init__()
        self.kernel_size = kernel_size
        self.basis_size = basis_size
        
        self.coeff_channel = out_chn * basis_size + add_chn
        self.basis_channel = 2 * out_chn * basis_size

        # Layer definition in each block
        # Encoder
        self.down_conv1 = DownBlock(in_dims, 64) #/2
        self.down_conv2 = DownBlock(64, 32) #/4
        self.down_conv3 = DownBlock(32, 32) #/8
        self.down_conv4 = DownBlock(32, 64) #/16
        
        # Decoder for coefficients
        self.up_coeff_conv3 = UpBlock(32, 32) 
        self.up_coeff_conv2 = UpBlock(32, 32)
        self.up_coeff_conv1 = UpBlock(32, 16)
        self.up_coeff_conv0 = UpBlock(16, 16)
        
        self.coeff_conv4 = SingleConv_res(64, 64)
        self.coeff_conv3 = SingleConv_res(32, 32)
        self.coeff_conv2 = SingleConv_res(32, 32)
        self.coeff_conv1 = SingleConv_res(32, 32)
        self.coeff_conv0_0 = SingleConv_res(16, 16)
        self.coeff_conv0_1 = SingleConv_res(16, 16)
        self.out_coeff =  nn.Conv2d(16, out_channels=self.coeff_channel , kernel_size=1,stride=1, padding=0)

        self.skip2 =  nn.Conv2d(32, 32 , kernel_size=1,stride=1, padding=0)
        self.skip1 =  nn.Conv2d(64, 32 , kernel_size=1,stride=1, padding=0)
        self.skip0 =  nn.Conv2d(in_dims, 16 , kernel_size=1,stride=1, padding=0)
        
        # Decoder for basis
        self.up_basis_conv4 = UpBlock_basis(64, 32, 64)
        self.up_basis_conv3 = UpBlock_basis(64, 32, 64)
        self.up_basis_conv2 = UpBlock_basis(64, 64, 64)
       
        self.basis_conv1 = CutEdgeConv(64, 64)
        self.out_basis = nn.Conv2d(64, out_channels=self.basis_channel , kernel_size=1,stride=1, padding=0)
        
        # Model weights initialization
        self.apply(self._init_weights)

    @staticmethod
    def _init_weights(m):
        if isinstance(m, nn.Conv2d):
            nn.init.xavier_normal_(m.weight.data)
            nn.init.constant_(m.bias.data, 0.0)
        elif isinstance(m, nn.ConvTranspose2d):
            nn.init.xavier_normal_(m.weight.data)
            nn.init.constant_(m.bias.data, 0.0)

    # forward propagation
    def forward(self, x):
        # down sampling
        #x /2
        down_features1 = self.down_conv1(x) #/4
        down_features2 = self.down_conv2(down_features1) #/8
        down_features3 = self.down_conv3(down_features2) #/16
        down_features4 = self.down_conv4(down_features3) #/32
        
        features4 = self.coeff_conv4(down_features4) #/32
        
        # up sampling with skip connection, for coefficients
        features3 = self.coeff_conv3(down_features3) #/16
        up_features2 = self.up_coeff_conv3(features3) #/8
        skip_features2 = self.skip2(down_features2)
        #print("====skip_features2:",skip_features2.size())
        #print("====up_features2:",up_features2.size())
        features2 = self.coeff_conv2(skip_features2+up_features2) #/8
        
        up_features1 = self.up_coeff_conv2(features2) #/4
        skip_features1 = self.skip1(down_features1)
        features1 = self.coeff_conv1(skip_features1+up_features1) #/4
        
        up_features0 = self.up_coeff_conv1(features1) #/2
        skip_features0 = self.skip0(x)
        features0 = self.coeff_conv0_0(skip_features0+up_features0) #/2
        features0 = self.coeff_conv0_1(features0) 

        up_features_final = self.up_coeff_conv0(features0) #/2
        coeff = self.out_coeff(up_features_final)
        #print("======coeff:",coeff.size())

        # up sampling with pooled-skip connection, for basis
        out = torch.mean(features4, axis=[2,3], keepdims=True) # 1x1
        out = self.up_basis_conv4(out, down_features3) # 2x2
        out = self.up_basis_conv3(out, down_features2) # 4x4
        out = self.up_basis_conv2(out, down_features1) # 8x8
        out = self.basis_conv1(out) #7x7
        basis = self.out_basis(out) #7x7
        #print("======basis:",basis.size())

        return coeff, basis
        
        
        

class CNN_NET_80G(nn.Module):
    def __init__(self,in_dims, out_chn):
        super(CNN_NET_80G, self).__init__()
        
        # Layer definition in each block
        # Encoder
        self.down_conv1 = DownBlock(in_dims, 64) #/2
        self.down_conv2 = DownBlock(64, 32) #/4
        self.down_conv3 = DownBlock(32, 64) #/8
        
        # Decoder for coefficients
        self.up_coeff_conv3 = UpBlock(32, 32) 
        self.up_coeff_conv2 = UpBlock(32, 32)
        self.up_coeff_conv1 = UpBlock(32, 16)
        self.up_coeff_conv0 = UpBlock(16, 16)
        
        self.coeff_conv3 = SingleConv_res(64, 32)
        self.coeff_conv2 = SingleConv_res(32, 32)
        self.coeff_conv1 = SingleConv_res(32, 32)
        self.coeff_conv0_0 = SingleConv_res(16, 16)
        self.coeff_conv0_1 = SingleConv_res(16, 16)
        self.out =  nn.Conv2d(16, out_chn, kernel_size=1,stride=1, padding=0)

        self.skip2 =  nn.Conv2d(32, 32 , kernel_size=1,stride=1, padding=0)
        self.skip1 =  nn.Conv2d(64, 32 , kernel_size=1,stride=1, padding=0)
        self.skip0 =  nn.Conv2d(in_dims, 16 , kernel_size=1,stride=1, padding=0)
        
        # Model weights initialization
        self.apply(self._init_weights)

    @staticmethod
    def _init_weights(m):
        if isinstance(m, nn.Conv2d):
            nn.init.xavier_normal_(m.weight.data)
            nn.init.constant_(m.bias.data, 0.0)
        elif isinstance(m, nn.ConvTranspose2d):
            nn.init.xavier_normal_(m.weight.data)
            nn.init.constant_(m.bias.data, 0.0)

    # forward propagation
    def forward(self, x):
        # down sampling
        #x /2
        down_features1 = self.down_conv1(x) #/4
        down_features2 = self.down_conv2(down_features1) #/8
        down_features3 = self.down_conv3(down_features2) #/16
        
        # up sampling with skip connection, 
        features3 = self.coeff_conv3(down_features3) #/16
        up_features2 = self.up_coeff_conv3(features3) #/8
        skip_features2 = self.skip2(down_features2)
        #print("====skip_features2:",skip_features2.size())
        #print("====up_features2:",up_features2.size())
        features2 = self.coeff_conv2(skip_features2+up_features2) #/8
        
        up_features1 = self.up_coeff_conv2(features2) #/4
        skip_features1 = self.skip1(down_features1)
        features1 = self.coeff_conv1(skip_features1+up_features1) #/4
        
        up_features0 = self.up_coeff_conv1(features1) #/2
        skip_features0 = self.skip0(x)
        features0 = self.coeff_conv0_0(skip_features0+up_features0) #/2
        features0 = self.coeff_conv0_1(features0) 

        up_features_final = self.up_coeff_conv0(features0) #/2
        out = self.out(up_features_final)



        return out



class CNN_NET_50G(nn.Module):
    def __init__(self,in_dims, out_chn):
        super(CNN_NET_50G, self).__init__()
        
        # Layer definition in each block
        # Encoder
        self.down_conv1 = DownBlock(16, 32) #/2
        self.down_conv2 = DownBlock(32, 32) #/4
        self.down_conv3 = DownBlock(32, 32) #/8
        
        # Decoder for coefficients
        self.up_coeff_conv3 = UpBlock(32, 32) 
        self.up_coeff_conv2 = UpBlock(32, 32)
        self.up_coeff_conv1 = UpBlock(32, 16)
        #self.up_coeff_conv0 = UpBlock(16, 16)
        
        self.coeff_conv3 = SingleConv_res2(32, 16, 32)
        self.coeff_conv2 = SingleConv_res2(32, 16, 32)
        self.coeff_conv1 = SingleConv_res2(32, 16, 32)
        self.coeff_conv0_0 = SingleConv_res(16, 16)
        self.coeff_conv0_1 = SingleConv_res_depthwise(16)
        self.out =  nn.Conv2d(32, out_chn, kernel_size=1,stride=1, padding=0)

        self.skip2 =  nn.Conv2d(32, 32 , kernel_size=1,stride=1, padding=0)
        self.skip1 =  nn.Conv2d(32, 32 , kernel_size=1,stride=1, padding=0)
        self.skip0 =  nn.Conv2d(in_dims, 16 , kernel_size=1,stride=1, padding=0)
        
        # Model weights initialization
        self.apply(self._init_weights)

    @staticmethod
    def _init_weights(m):
        if isinstance(m, nn.Conv2d):
            nn.init.xavier_normal_(m.weight.data)
            nn.init.constant_(m.bias.data, 0.0)
        elif isinstance(m, nn.ConvTranspose2d):
            nn.init.xavier_normal_(m.weight.data)
            nn.init.constant_(m.bias.data, 0.0)

    # forward propagation
    def forward(self, x):
        # down sampling
        #x /2
        skip_features0 = self.skip0(x)
        down_features1 = self.down_conv1(skip_features0) #/4
        down_features2 = self.down_conv2(down_features1) #/8
        down_features3 = self.down_conv3(down_features2) #/16
        
        # up sampling with skip connection, 
        features3 = self.coeff_conv3(down_features3) #/16
        up_features2 = self.up_coeff_conv3(features3) #/8
        skip_features2 = self.skip2(down_features2)
        #print("====skip_features2:",skip_features2.size())
        #print("====up_features2:",up_features2.size())
        features2 = self.coeff_conv2(skip_features2+up_features2) #/8
        
        up_features1 = self.up_coeff_conv2(features2) #/4
        skip_features1 = self.skip1(down_features1)
        features1 = self.coeff_conv1(skip_features1+up_features1) #/4
        
        up_features0 = self.up_coeff_conv1(features1) #/2
        
        features00 = self.coeff_conv0_0(skip_features0+up_features0) #/2
        features01 = self.coeff_conv0_1(features00) 

        features_final = torch.cat([up_features0,features01],dim = 1)
        out = self.out(features_final)


        return out        