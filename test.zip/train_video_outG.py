import os
import argparse
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torchvision.utils as utils
from torch.autograd import Variable
from torch.utils.data import DataLoader
from tensorboardX import SummaryWriter
from models import CNN_NET_50G

from utils import apply_gamma,var_calc,linear_inter,apply_blc,space_to_depth
import cv2
from contextual_loss import ContextualLoss
import heaviside_pytorch
import HEM_pytorch
from torch.cuda.amp import autocast, GradScaler
from temporal_loss import temporal_consistency_loss 
from pytorch_ssim import SSIM
from tv_loss import TVLoss
#import sys 
#sys.path.append("..") 
#from gen_data_code import  dataset_video
import h5py
import glob
import torch.utils.data as udata


print_all_frm = 0

os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

parser = argparse.ArgumentParser(description="DnCNN")
parser.add_argument("--train_data_path", type=str, default="train_data", help='path of train_data')
parser.add_argument("--batchSize", type=int, default=16, help="Training batch size")
parser.add_argument("--pretrained_ckpt", type=int, default=0, help="Training batch size")
parser.add_argument("--epochs", type=int, default=50, help="Number of training epochs")
parser.add_argument("--lr", type=float, default=2.0e-4, help="Initial learning rate")
parser.add_argument("--outf", type=str, default="logs", help='path of log files')
parser.add_argument("--lr_stage0_count", type=int, default=100000, help='how much count used in stage 0 for lr')
opt = parser.parse_args()



    

class Dataset(udata.Dataset):
    def __init__(self, train_data_path, train=True):
        super(Dataset, self).__init__()
        self.train = train
        
        print(train_data_path)
        
        file_list = glob.glob(train_data_path + "*.h5")
        
        self.file_list = file_list

        #random.shuffle(self.keys)
        self.sample_len = len(file_list)
        print("=======sample_len:",self.sample_len)

    def __len__(self):
        return self.sample_len
    def __getitem__(self, index):
        
        h5 = self.file_list[index]

        h5f = h5py.File(h5, 'r')

        label = np.array(h5f['label'])[0]
        xymap = np.array(h5f['xymap'])[0]
        
        data = np.array(h5f['data']).astype(np.float32)[0]

        data = data/(2**12 - 1)
        
        var_map = np.array(h5f['var_map']).astype(np.float32)[0]
        var_map = var_map/(2**12 - 1)
        
        #for frm_idx in range (15):
        #    tmp = np.clip(label[frm_idx]*255*2,0,255)
        #    out_file_pth = "./tmp2/%d_%d.bmp"%(index,frm_idx)
        #    cv2.imwrite(out_file_pth, tmp)
        #    
        #    tmp = np.float32(xymap[frm_idx])
        #    #print("================xymap1:",np.shape(xymap),np.shape(data[frm_idx]))
        #    last_frame_warp = cv2.remap(label[frm_idx], tmp[0], tmp[1], cv2.INTER_NEAREST)
        #    tmp = np.clip(last_frame_warp*255*2,0,255)
        #    out_file_pth = "./tmp2/%d_%d_warp.bmp"%(index,frm_idx)
        #    cv2.imwrite(out_file_pth, tmp)
            
        
        h5f.close()
        return torch.Tensor(data),torch.Tensor(label),torch.Tensor(xymap),torch.Tensor(var_map)

        
"""
class BPN(nn.Module):
    def __init__(self, B = 8,K=7):
        super(BPN, self).__init__()
        self.B = B
        self.K = K
        padding = 1
        features = 64
        self.conv = nn.Conv2d
        
    def forward(self, kernel, coeff, image):
        k = self.K
        chn,c,w,h = image.size()
        kernel = 2/(1+torch.exp(-kernel)) - 1.0  
        kernel_r = kernel[:,:self.B,:,:].reshape(chn*B,1,k,k)
        kernel_g = kernel[:,self.B:2*self.B,:,:].reshape(chn*B,1,k,k)
        kernel_b = kernel[:,2*self.B:,:,:].reshape(chn*B,1,k,k)
        
        r = image[:,0:1,:,:].reshape(1,chn,w,h)
        g = image[:,1:2,:,:].reshape(1,chn,w,h)
        b = image[:,2:3,:,:].reshape(1,chn,w,h)
        
        r = F.pad(r,(k//2,k//2,k//2,k//2),mode='reflect')
        g = F.pad(g,(k//2,k//2,k//2,k//2),mode='reflect')
        b = F.pad(b,(k//2,k//2,k//2,k//2),mode='reflect')
        
        r_f = self.conv(r,kernel_r, group=chn)
        g_f = self.conv(g,kernel_g, group=chn)
        b_f = self.conv(b,kernel_b, group=chn)
        
        coeff_r = coeff[:,:self.B,:,:]
        coeff_g = coeff[:,self.B:2*self.B,:,:]
        coeff_b = coeff[:,2*self.B:,:,:]
        
        coeff_r = torch.softmax(coeff_r,dim=1)
        coeff_g = torch.softmax(coeff_g,dim=1)
        coeff_b = torch.softmax(coeff_b,dim=1)
        
        r_f = r_f.view(chn,-1,w,h)
        g_f = g_f.view(chn,-1,w,h)
        b_f = b_f.view(chn,-1,w,h)
        
        r_f = r_f*coeff_r
        g_f = r_f*coeff_g
        b_f = r_f*coeff_b
        
        
        r_f = torch.sum(r_f,dim=1, keepdim=True)
        g_f = torch.sum(g_f,dim=1, keepdim=True)
        b_f = torch.sum(b_f,dim=1, keepdim=True)
        
        out = torch.cat([r_f,g_f,b_f],dim=1)
        
        return out
"""

class BPN_rec(nn.Module):
    def __init__(self, B = 8,K=7):
        super(BPN_rec, self).__init__()
        self.B = B
        self.K = K
        
    def forward(self, coeff, kernel, image):
        k = self.K
        chn,c,w,h = image.size()
        kernel = 2/(1+torch.exp(-kernel)) - 1.0  
        
        out = torch.zeros_like(image).cuda()
        for idx in range (c) : 
        
            kernel_cur = kernel[:,idx*self.B:(idx+1)*self.B,:,:].reshape(chn*self.B,1,k,k)

            I = image[:,idx:idx+1,:,:].reshape(1,chn,w,h)
            I = F.pad(I,(k//2,k//2,k//2,k//2),mode='reflect')
            
            I_f = F.conv2d(I,kernel_cur, groups=chn)
            
            coeff_cur = coeff[:,idx*self.B:(idx+1)*self.B,:,:]
            
            coeff_cur = torch.softmax(coeff_cur,dim=1)
            
            I_f = I_f.view(chn,-1,w,h)
            
            I_f = I_f*coeff_cur
            
            I_f = torch.sum(I_f,dim=1, keepdim=True)
            
            out[:,idx:idx+1,:,:] = I_f
        #print("====out:",out.size())        
        return out

#torch
def warp_torch(x,xymap,w,h):
    
    vgrid_x = 2.0 * xymap[:, 0,:, :] / max(w - 1, 1) - 1.0
    vgrid_y = 2.0 * xymap[:, 1,:, :] / max(h - 1, 1) - 1.0

    vgrid_scaled = torch.stack((vgrid_x, vgrid_y), dim=3)
    output = F.grid_sample(x, vgrid_scaled, mode='nearest', padding_mode='reflection')
         
    return  output   

def main():
    pretrained_ckpt = opt.pretrained_ckpt
    
    # Load dataset
    print('Loading dataset ...\n')
    dataset_train = Dataset(train_data_path = opt.train_data_path,train=True)
    

    loader_train = DataLoader(dataset=dataset_train, num_workers=1, batch_size=opt.batchSize, shuffle=True)
    print("# of training samples: %d\n" % int(len(dataset_train)))
    # Build model
    
    #in raw + pre g : 4+4 + 4
    net = CNN_NET_50G(in_dims = 12, out_chn = 4)
    
    
    scaler = GradScaler()
    
    warm_up_step = 6000
    if pretrained_ckpt > 0:
        warm_up_step = 0
        checkpoint_PATH = os.path.join(opt.outf, 'net_epoch%d.pth'%(pretrained_ckpt))
        model_CKPT = torch.load(checkpoint_PATH)    # 加载模型参数
        
        model_CKPT_new = {k.replace('module.',''):v for k,v in model_CKPT.items()}
        
        net.load_state_dict(model_CKPT_new)  
        print("load pre trained ckpt ",pretrained_ckpt,warm_up_step)
    
    
    #################load a pre trained DM net for raw
    """
    net_dm = DM_NET(in_dims = 24, out_chn = 3)

    checkpoint_PATH = os.path.join(opt.outf, 'net_epoch%d.pth'%(pretrained_ckpt_dm))
    model_CKPT = torch.load(checkpoint_PATH)    # 加载模型参数
    
    model_CKPT_new = {k.replace('module.',''):v for k,v in model_CKPT.items()}
    
    net_dm.load_state_dict(model_CKPT_new)  
    model_dm = nn.DataParallel(net_dm, device_ids=device_ids).cuda()    
    """    
    #net.apply(weights_init_kaiming)

    
    ctx_loss_func = ContextualLoss(add_noise = True,noise_scale = 1.0)
    ctx_loss_func2 = ContextualLoss(add_noise = True,noise_scale = 1.0)
    hem_loss_func = HEM_pytorch.HEM()
    
    var_calc_func = var_calc(channels = 1, kernel_size = 5, use_hf = True)
    temporal_consistency_func = temporal_consistency_loss()
    ssim_func = SSIM()
    tvloss_func = TVLoss()


    l1_w = 0.1
    hem_w = 2
    ssim_w = 0.15
    ctx_w = 0.001
    tv_w = 0.6
    tc_w = 0.8
    
    
    lr_th_for_ft = 8.5e-5

    
    # Move to GPU
    device_ids = [0]
    model = nn.DataParallel(net, device_ids=device_ids).cuda()
    
    # Optimizer
    optimizer = optim.AdamW(model.parameters(), lr=opt.lr)
    # training
    writer = SummaryWriter(opt.outf)
    step_count = 0
    noiseL_B=[0,55] # ingnored when opt.mode=='S'
    for epoch in range(pretrained_ckpt+1,pretrained_ckpt + opt.epochs):
        
        if step_count < 40000:
            current_lr = opt.lr
        elif step_count < 200000:
            current_lr = opt.lr *0.65
        elif step_count < 350000:
            current_lr = opt.lr*0.65
        else:
            current_lr = opt.lr*0.65

                
        # set learning rate
        for param_group in optimizer.param_groups:
            param_group["lr"] = current_lr
        #print('learning rate %f' % current_lr)
        
        for i, [data,label,data_xymap,var_map] in enumerate(loader_train, 0):
            # training step
            #torch.cuda.empty_cache()
            
            model.train()
            model.zero_grad()
            optimizer.zero_grad()
            
            #print ("===================data:",data.size(),label.size(),data_xymap.size(),var_map.size())

            target = label.permute(0,1,4,2,3)
            data = data.permute(0,1,4,2,3)
            var_map = var_map.permute(0,1,4,2,3)
            
            #print ("===================target:",target.size())
            #if opt.mode == 'S':
            #    noise = torch.FloatTensor(target.size()).normal_(mean=0, std=opt.noiseL/255.)
            #if opt.mode == 'B':
            #    noise = torch.zeros(target.size())
            #    stdN = np.random.uniform(noiseL_B[0], noiseL_B[1], size=noise.size()[0])
            #    for n in range(noise.size()[0]):
            #        sizeN = noise[0,:,:,:].size()
            #        noise[n,:,:,:] = torch.FloatTensor(sizeN).normal_(mean=0, std=stdN[n]/255.)

            target, net_noisey_in,var_map_in,data_xymap_in = Variable(target), Variable(data), Variable(var_map), Variable(data_xymap)
            
            var_map_in = var_map_in/80
            
            #noise = Variable(noise.cuda())
            #data_xymap = data_xymap.cuda()
            target = target.cuda()
            net_noisey_in = net_noisey_in.cuda()
            var_map_in = var_map_in.cuda()
            data_xymap_in = data_xymap_in.cuda()
            
            #with autocast():
            if step_count < warm_up_step:
                l1_w = 1.0
                hem_w = 0.001
                ssim_w = 0.001
                ctx_w = 0.00001
                tv_w = 0.001
                tc_w = 0.001
            else:
                l1_w = 0.1
                hem_w = 0.8
                ssim_w = 0.08
                ctx_w = 0.015
                tv_w = 1.2
                tc_w = 0.8
                
            l1_loss = 0
            hem_loss = 0
            ctx_loss = 0
            tv_loss = 0
            ssim_loss = 0
            tc_loss = 0
            
            rand_idx = np.random.randint(low = 0,high = opt.batchSize)
            for frm_idx in range (15):
                net_noisey_in_cur = net_noisey_in[:,frm_idx,:,:,:]
                target_cur = target[:,frm_idx,:,:,:]
                var_map_cur = var_map_in[:,frm_idx,:,:,:]
                xymap_cur = data_xymap_in[:,frm_idx,:,:,:]
                #print("===========net_noisey_in:",net_noisey_in.size())
                
                label_G = target_cur[:,1:2,:,:] #only g
                
                zeros_map = torch.zeros_like(label_G).cuda()
                if frm_idx == 0:
                    pre_warp = zeros_map
            
                
                ##############################
                luma_orig = target_cur[:,1:2,:,:]
                luma_gamma = torch.maximum(luma_orig - 1.0/16.0,zeros_map)**(1.0/2.2)
                
                detal_map = var_calc_func(luma_gamma)
                
                #calc flat region map
                p0 = [3 ,1.0]
                p1 = [15,0.0]
                flat_mask = linear_inter(p0,p1,detal_map)
                
                #calc luma  map
                p0 = [0.065 ,1.0]
                p1 = [0.07  ,0.0]
                luma_mask = linear_inter(p0,p1,detal_map)
                
                ##############################
                
                
                pre_in = space_to_depth(pre_warp,2)
                
                net_in = torch.cat([net_noisey_in_cur,pre_in,var_map_cur],1)
                
                #
                out_train_sub = model(net_in)
                out_train = torch.pixel_shuffle(out_train_sub,2)
                
                out_train_gamma = apply_blc(out_train,1.0/16.0)
                label_gamma = apply_blc(label_G,1.0/16.0)
                out_train_gamma = apply_gamma(out_train_gamma)
                label_gamma = apply_gamma(label_gamma)
                ###########################
                    
                #=============================================================
                
                flat_mask_l1 = flat_mask*2 + 1
                l1_loss += torch.mean(torch.abs(out_train_gamma - label_gamma) *flat_mask_l1)
                #smape loss
                #l1_loss = torch.mean(torch.abs(out_train - target_cur) * (1 + (asym_w-1) * h)/(target_cur + torch.abs(out_train) + 1e-3))

                tv_loss += torch.mean(torch.abs(tvloss_func(out_train_gamma)-tvloss_func(label_gamma)))
                #============================================================
                luma_mask_hem = luma_mask + 1
                hem_loss += hem_loss_func(label_gamma,out_train_gamma,luma_mask_hem)
                
                ssim_loss += 1.0 - torch.clamp(ssim_func(out_train_gamma,label_gamma),0.0,1.0)
                
                #out_train_3chn = torch.cat([out_train,out_train,out_train],dim=1)
                #target_3chn = torch.cat([target,target,target],dim=1)
                out_train_gamma_3chn = torch.cat([out_train_gamma,out_train_gamma,out_train_gamma],dim = 1)
                label_gamma_3chn = torch.cat([label_gamma,label_gamma,label_gamma],dim = 1)
                ctx_loss +=  ctx_loss_func(out_train_gamma_3chn, label_gamma_3chn)
                
                #finetune quality with more loss
                if current_lr <= lr_th_for_ft: 
                    net_out_inv = (1.0-out_train_gamma_3chn)*0.35
                    label_inv = (1.0-label_gamma_3chn)*0.35

                    ctx_loss += 0.6*ctx_loss_func2(net_out_inv, label_inv)
                
                    if frm_idx > 0:
                        frm_w = 1
                        if frm_idx > 8:
                            frm_w = 3
                        tc_loss += frm_w*temporal_consistency_func(label_gamma,label_ref, out_train_gamma,out_train_ref)
                
                    label_ref =  label_gamma.clone()
                    out_train_ref =  out_train_gamma.clone()
                
                if step_count < warm_up_step//2:
                    pre_warp = warp_torch(label_G,xymap_cur,128,128)
                else:
                    pre_warp = warp_torch(out_train,xymap_cur,128,128)
                    
                if step_count % 1000 == 0 and ((frm_idx == 12) or print_all_frm == 1):
                    out_np = label_G[rand_idx,:,:,:].cpu().detach().numpy()
                    tmp = out_np.transpose((1, 2, 0))
                    tmp = np.clip(tmp-0.9/16.0,0,1)**(1.0/2.2)
                    tmp = np.clip(tmp*255,0,255)
                    out_file_pth = opt.outf + "/train_output/%d_%d_%d_label.bmp"%(step_count,rand_idx,frm_idx)
                    #print("=------------------out_file_pth :",out_file_pth)
                    cv2.imwrite(out_file_pth, tmp)
                    
                    #out_np = label_gamma[0,:,:,:].cpu().detach().numpy()
                    #tmp = out_np.transpose((1, 2, 0))
                    #tmp = np.clip(tmp*255,0,255)
                    #out_file_pth = opt.outf + "/train_output/%d_label_GAMMAt_%d.bmp"%(step_count,frm_idx)
                    #cv2.imwrite(out_file_pth, tmp)
                    
                    #out_np = detal_map[0,:,:,:].cpu().detach().numpy()
                    #tmp = out_np.transpose((1, 2, 0))
                    #tmp = np.clip(tmp,0,255)
                    #out_file_pth = opt.outf + "/train_output/%d_detal_map_%d.bmp"%(step_count,frm_idx)
                    #cv2.imwrite(out_file_pth, tmp)
                    
                    out_np = net_noisey_in_cur[rand_idx,1:2,:,:].cpu().detach().numpy()
                    tmp = out_np.transpose((1, 2, 0))
                    tmp = np.clip(tmp-0.9/16.0,0,1)**(1.0/2.2)
                    tmp = np.clip(tmp*255,0,255)
                    out_file_pth = opt.outf + "/train_output/%d_%d_%d_noisy.bmp"%(step_count,rand_idx,frm_idx)
                    cv2.imwrite(out_file_pth, tmp)
                    
                    out_np = pre_warp[rand_idx,:,:,:].cpu().detach().numpy()
                    tmp = out_np.transpose((1, 2, 0))
                    tmp = np.clip(tmp-0.9/16.0,0,1)**(1.0/2.2)
                    tmp = np.clip(tmp*255,0,255)
                    out_file_pth = opt.outf + "/train_output/%d_%d_%d_netout_warp.bmp"%(step_count,rand_idx,frm_idx)
                    cv2.imwrite(out_file_pth, tmp)
                    
                    out_np = out_train[rand_idx,:,:,:].cpu().detach().numpy()
                    tmp = out_np.transpose((1, 2, 0))
                    tmp = np.clip(tmp-0.9/16.0,0,1)**(1.0/2.2)
                    tmp = np.clip(tmp*255,0,255)
                    out_file_pth = opt.outf + "/train_output/%d_%d_%d_netout.bmp"%(step_count,rand_idx,frm_idx)
                    cv2.imwrite(out_file_pth, tmp)
                    
                    
            #scaler.scale(loss).backward()
            #scaler.step(optimizer)
            #scaler.update()
            
            l1_loss_o = l1_w * l1_loss
            ssim_loss_o = ssim_w * ssim_loss
            tv_loss_o = tv_w * tv_loss
            ctx_loss_o = ctx_w * ctx_loss
            hem_loss_o = hem_w*hem_loss
            
            loss = l1_loss_o + hem_loss_o + ctx_loss_o + tv_loss_o + ssim_loss_o
            if current_lr < lr_th_for_ft: 
                tc_loss_o = tc_w * tc_loss
                loss += tc_loss_o
            
            loss.backward()
            optimizer.step()
            
            
            if step_count == 0:
                loss_total_avg = 0
                l1_total_avg = 0
                ctx_total_avg = 0
                hem_avg = 0
                ssim_avg = 0
                tv_avg = 0
                tc_avg = 0
            
            loss_total_avg += loss.item()
            l1_total_avg += l1_loss_o.item()
            ctx_total_avg += ctx_loss_o.item()
            hem_avg += hem_loss_o.item()
            tv_avg += tv_loss_o.item()
            ssim_avg += ssim_loss_o.item()
            if current_lr < lr_th_for_ft: 
                tc_avg += tc_loss_o
            
            if step_count % 200 == 0:
                loss_total_avg = loss_total_avg/200
                l1_total_avg = l1_total_avg/200
                ctx_total_avg = ctx_total_avg/200
                hem_avg = hem_avg/200
                tv_avg = tv_avg/200
                ssim_avg = ssim_avg/200
                tc_avg = tc_avg/200
                
                print("[epoch %02d][step %d]loss: total = %.2f , l1 = %.5f, ctx = %.2f , hem = %.2f ,tv_avg= %.2f,ssim_avg= %.2f,tc_avg= %.2f, lr = %.1f" %(epoch,step_count, loss_total_avg,l1_total_avg,ctx_total_avg,hem_avg,tv_avg,ssim_avg,tc_avg,current_lr*10000))
                
                loss_total_avg = 0
                l1_total_avg = 0
                ctx_total_avg = 0
                hem_avg = 0
                tv_avg = 0
                ssim_avg = 0
                tc_avg = 0
                
            #if step_count % 1000 == 0:
            #    torch.save(model.state_dict(), os.path.join(opt.outf, 'net_step%d.pth'%(step)))
                
            step_count += 1
        
        ckpt_out_filepath = os.path.join(opt.outf, 'net_epoch%d.pth'%(epoch))
        print("save ckpt :",ckpt_out_filepath)
        torch.save(model.state_dict(), ckpt_out_filepath)

if __name__ == "__main__":

    main()
