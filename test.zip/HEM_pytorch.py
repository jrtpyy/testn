import torch
import torch.nn as nn
import numpy as np

class HEM(nn.Module):
    def __init__(self,p0 = 0.5,p1 = 0.1):
        super(HEM, self).__init__()
        self.p0 = p0
        self.p1 = p1
        
    def get_mask(self,x,y):
        with torch.no_grad():
            b,c,h,w = x.size()
            mask = np.zeros((b,1*w*h))
            diff = torch.abs(x-y).sum(dim=1).view(b,-1)
            diff_sort = [diff[i].sort(descending=True) for i in range (b)]
            diff_np = diff.cpu().numpy()
            hard_th_idx = int(self.p0*w*h)
            for i in range(b):
                hard_th = diff_sort[i][0][hard_th_idx].item()
                mask[i] = (diff_np[i] > hard_th).astype(int)
                
            rand_hart_th_idx = int(self.p1*w*h)
            mask_rand = np.zeros((b,1*w*h))
            for i in range(b):
                mask_rand[i,0:rand_hart_th_idx] = 1
                np.random.shuffle(mask_rand[i])
                
            mask = mask + mask_rand
            mask = (mask>0).astype(int)
            mask = mask.reshape(b,-1,h,w)
        return torch.from_numpy(mask).cuda()


    def forward(self, x, y,weight):
        mask = self.get_mask(x.detach(),y.detach())
        loss = torch.mean(torch.abs(x-y)*mask*weight)
        return loss